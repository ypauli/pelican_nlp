PELICAN – Preprocessing and Extraction of Linguistic Information for Computational Analysis

PELICAN is a language processing pipeline for preprocessing and extracting language features from various text files...

To optimize performance close other programs and limit gpu usage during language processing